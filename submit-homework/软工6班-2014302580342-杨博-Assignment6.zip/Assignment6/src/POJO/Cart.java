package POJO;

import java.util.Map;

public class Cart {
	private int id;
	private int goodsId;
	private int goodsNumber;
	private int customerId;

	public int getId() {
		return id;
	}

	public void setId(int id){
		this.id = id;
		
	}
	public int getGoodsId(){
		return this.goodsId;
	}
	public void setGoodsId(int goodsId){
		this.goodsId = goodsId;
	}
	public int getGoodsNumber(){
		return goodsNumber;
		
	}
	public void setGoodsNumber(int goodsNumber){
		this.goodsNumber = goodsNumber;
	}
	public void setCustomerId(int c){
		this.customerId = c;
	}
	public int getCustomerID(){
		return this.customerId;
	}
	
}
