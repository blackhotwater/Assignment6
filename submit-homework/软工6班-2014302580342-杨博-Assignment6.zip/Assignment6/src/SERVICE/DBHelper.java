package SERVICE;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.mysql.jdbc.ResultSetMetaData;

import POJO.Cart;
import POJO.Customer;
import POJO.Goods;


public class DBHelper {
	
	private static String url = "jdbc:mysql://127.0.0.1:3306/my_schema?"+
	"user=root&password=123456";

    private Connection connnection = null;  
  
 
    private PreparedStatement preparedStatement = null;  
      

    private ResultSet resultSet = null;  
    
	private static Connection getConnection(String url) {
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url);
			return conn;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

    public void customerInsert( Customer cus) {  
        // ��Ӱ�������  
        int affectedLine = 0;  
          String sql = "insert into 2014302580342_customer (account,password,phonenumber,email,balance) values(?,?,?,?,?)";
        try {  
            // �������  
            connnection = this.getConnection(url);  
            // ����SQL   
            preparedStatement = connnection.prepareStatement(sql);  
              
            // ������ֵ  
            preparedStatement.setString(1, cus.getAccount());
            preparedStatement.setString(2, cus.getPassword());
            preparedStatement.setString(3, cus.getPhoneNumber());
            preparedStatement.setString(4, cus.getEmail());
            preparedStatement.setDouble(5, cus.getBalance());
            // ִ��  
            affectedLine = preparedStatement.executeUpdate();  
  
        } catch (SQLException e) {  
            System.out.println(e.getMessage());  
        } finally {  
            // �ͷ���Դ  
        	try {
				connnection.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }  
    }  
    public void CartInsert( Cart cart) {  
        // ��Ӱ�������  
        int affectedLine = 0;  
          String sql = "insert into 2014302580342_cart (goods_id,goods_number,customer_id) values(?,?,?)";
        try {  
            // �������  
            connnection = this.getConnection(url);  
            // ����SQL   
            preparedStatement = connnection.prepareStatement(sql);  
              
            // ������ֵ  
            preparedStatement.setInt(1,cart.getGoodsId());
            preparedStatement.setInt(2,cart.getGoodsNumber());
            preparedStatement.setInt(3,cart.getCustomerID());
            // ִ��  
            affectedLine = preparedStatement.executeUpdate();  
  
        } catch (SQLException e) {  
            System.out.println(e.getMessage());  
        } finally {  
            // �ͷ���Դ  
        	try {
				connnection.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }  
    }  
    
    public  int cartUpdate(Cart cart) {
    	
        int i = 0;
        String sql = "update 2014302580342_cart set goods_number='" + cart.getGoodsNumber() + "' where id='" + cart.getId() + "'";
        try {
        	connnection = this.getConnection(url);  
        	   // ����SQL   
            preparedStatement = connnection.prepareStatement(sql);  
            i =  preparedStatement.executeUpdate();
            System.out.println("resutl: " + i);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {  
            // �ͷ���Դ  
        	try {
				connnection.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }  
        return i;
    }
   public  int goodsUpdate(Goods goods) {
    	
        int i = 0;
        String sql = "update 2014302580342_goods set inventory='" + goods.getInventory()+ "' where id='" + goods.getId() + "'";
        try {
        	connnection = this.getConnection(url);  
        	   // ����SQL   
            preparedStatement = connnection.prepareStatement(sql);  
            i =  preparedStatement.executeUpdate();
            System.out.println("resutl: " + i);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {  
            // �ͷ���Դ  
        	try {
				connnection.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }  
        return i;
    }
   public  int customerUpdate(Customer customer) {
   	
       int i = 0;
       String sql = "update 2014302580342_customer set balance='" + customer.getBalance()+ "' where id='" + customer.getId() + "'";
       try {
       	connnection = this.getConnection(url);  
       	   // ����SQL   
           preparedStatement = connnection.prepareStatement(sql);  
           i =  preparedStatement.executeUpdate();
           System.out.println("resutl: " + i);
       } catch (SQLException e) {
           e.printStackTrace();
       } finally {  
           // �ͷ���Դ  
       	try {
				connnection.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
       	try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
       }  
       return i;
   }
    public ArrayList<Customer> getCusInfo(){
    	ArrayList<Customer> list = new ArrayList<Customer>();
    	
    	String sql = "select * from 2014302580342_customer";
   
        try {
        	// �������  
            connnection = this.getConnection(url);  
            // ����SQL  
			preparedStatement = connnection.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
				while(rs.next()){
					Customer temp =  new Customer();
					temp.setId(rs.getInt(1));
					temp.setAccount(rs.getString(2));
					temp.setPassword(rs.getString(3));
					temp.setBalance(rs.getDouble(6));
					list.add(temp);
					}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {  
            // �ͷ���Դ  
           	try {
    				connnection.close();
    			} catch (SQLException e1) {
    				// TODO Auto-generated catch block
    				e1.printStackTrace();
    			}
           	try {
    				preparedStatement.close();
    			} catch (SQLException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
           }  
    	return list;
    }
    public ArrayList<Cart> getCartInfo(){
    	ArrayList<Cart> list = new ArrayList<Cart>();
    
    	String sql = "select * from 2014302580342_cart";
   
        try {
        	// �������  
            connnection = this.getConnection(url);  
            // ����SQL  
			preparedStatement = connnection.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()){
					Cart temp =  new Cart();
					temp.setId(rs.getInt(1));
					temp.setGoodsId(rs.getInt(2));
					temp.setGoodsNumber(rs.getInt(3));
					temp.setCustomerId(rs.getInt(4));
					list.add(temp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  finally {  
            // �ͷ���Դ  
           	try {
    				connnection.close();
    			} catch (SQLException e1) {
    				// TODO Auto-generated catch block
    				e1.printStackTrace();
    			}
           	try {
    				preparedStatement.close();
    			} catch (SQLException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
           }  
    	return list;
    }
    public ArrayList<Goods> getGoodsInfo(){
    	ArrayList<Goods> list = new ArrayList<Goods>();
    
    	String sql = "select * from 2014302580342_goods";
   
        try {
        	// �������  
            connnection = this.getConnection(url);  
            // ����SQL  
			preparedStatement = connnection.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()){
					Goods temp =  new Goods();
					temp.setId(rs.getInt(1));
					temp.setName(rs.getString(2));
					temp.setSpecies(rs.getString(3));
					temp.setEat(rs.getString(4));
					temp.setPrice(rs.getDouble(5));
					temp.setInventory(rs.getInt(6));
					list.add(temp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  finally {  
            // �ͷ���Դ  
           	try {
    				connnection.close();
    			} catch (SQLException e1) {
    				// TODO Auto-generated catch block
    				e1.printStackTrace();
    			}
           	try {
    				preparedStatement.close();
    			} catch (SQLException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
           }  
    	return list;
    }
    public int cartDelete(int accountId) {
    	int i = 0;
        String sql = "delete from 2014302580342_cart where customer_id='" + accountId + "'";
        PreparedStatement pstmt;
        try {
        	// �������  
            connnection = this.getConnection(url);  
         // ����SQL  
         	preparedStatement = connnection.prepareStatement(sql);
            i = preparedStatement.executeUpdate();
            System.out.println("resutl: " + i);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {  
            // �ͷ���Դ  
           	try {
    				connnection.close();
    			} catch (SQLException e1) {
    				// TODO Auto-generated catch block
    				e1.printStackTrace();
    			}
           	try {
    				preparedStatement.close();
    			} catch (SQLException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
           }  
        return i;
    }
}
    
