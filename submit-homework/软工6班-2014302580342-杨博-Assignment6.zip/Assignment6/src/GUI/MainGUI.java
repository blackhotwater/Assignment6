package GUI;

import javax.imageio.ImageIO;
import javax.swing.*;

import POJO.Cart;
import POJO.Customer;
import POJO.Goods;
import SERVICE.DBHelper;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;


public class MainGUI {
		DBHelper db = new DBHelper();	
		String nowAccount = "";
		int recentAccountId = 0;
		double recentBalance = 0;

		/*��¼����ļ�ʵ��
		 *  12.2
		 * �д�����
		 */
		JFrame login = new JFrame("Log in");
		JTextField login_account = new JTextField();
		JPasswordField login_password = new JPasswordField();
		private JLabel getBackGround(){
			JLabel j = new JLabel();
		    try {
		    	String src = "/img/bg.jpg";
				Image image=ImageIO.read(this.getClass().getResource(src));
				ImageIcon bg = new ImageIcon(image);
				bg.setImage(bg.getImage().getScaledInstance(bg.getIconWidth(), bg.getIconHeight(), Image.SCALE_DEFAULT));
				j.setBounds(0, 0, 800, 600);
				j.setIcon(bg);
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return j;
	
		}
		private JLabel getMaintitle(){
			JLabel j = new JLabel();
			j.setText("Shizuka's Magic Store");
			j.setBounds(150, 20, 600, 100);
			j.setFont(new Font("Calibri Light Italic",Font.BOLD,45));
			j.setForeground(Color.white);
			return j;
		}
		private JLabel getLogo(){
			JLabel j = new JLabel();
		    try {
		    	String src = "/img/logo.png";
				Image image=ImageIO.read(this.getClass().getResource(src));
				ImageIcon logo = new ImageIcon(image);
				logo.setImage(logo.getImage().getScaledInstance(logo.getIconWidth(), logo.getIconHeight(), Image.SCALE_DEFAULT));
				j.setBounds(20, 20, 100, 100);
				j.setIcon(logo);
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return j;
		}
		private JLabel getIcoUser(){
			JLabel j = new JLabel();
		    try {
		    	String src = "/img/ico1.png";
				Image image=ImageIO.read(this.getClass().getResource(src));
				ImageIcon logo = new ImageIcon(image);
				logo.setImage(logo.getImage().getScaledInstance(logo.getIconWidth(), logo.getIconHeight(), Image.SCALE_DEFAULT));
				j.setBounds(260, 170, 30, 30);
				j.setIcon(logo);
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return j;
		}
		private JLabel getIcoPassword(){
			JLabel j = new JLabel();
		    try {
		    	String src = "/img/ico2.png";
				Image image=ImageIO.read(this.getClass().getResource(src));
				ImageIcon logo = new ImageIcon(image);
				logo.setImage(logo.getImage().getScaledInstance(logo.getIconWidth(), logo.getIconHeight(), Image.SCALE_DEFAULT));
				j.setBounds(260, 210, 30, 30);
				j.setIcon(logo);
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return j;
		}
		private JTextField getUsernameField() {
			login_account .setBounds(300, 170,170,30);
			login_account .setFont(new Font("΢���ź�",Font.BOLD,17));
			 return login_account ;
		}

		private JPasswordField getJPasswordField() {
			login_password.setBounds(300, 210, 170, 30);
			login_password.setFont(new Font("΢���ź�",Font.BOLD,17));
			return login_password;
		}	 
		
		private JButton getJButtonLog(){
			JButton button = new JButton();
			button.setText("����");
			button.setFont(new Font("΢���ź�",0,13));
			button.setBounds(302, 260, 68, 25);
			button.setBackground(Color.white);
			button.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	              boolean flag = false;
	              Customer temp = new Customer();
	              temp.setAccount(login_account.getText());
	              char[] password = login_password.getPassword();
	              temp.setPassword(new String(password));
	              ArrayList<Customer> list =  db.getCusInfo();
	              for(Customer a:list){
	            	  if(a.getAccount().equals(temp.getAccount()) && a.getPassword().equals(temp.getPassword())){
	            		  nowAccount = a.getAccount();
	            		  recentAccountId = a.getId();
	            		  recentBalance = a.getBalance();
	            		  login.setVisible(false);
	            		  main.setVisible(true);
	            		  flag = true;
	            		  break;
	            	  }
	              }
	              if(!flag){
	              JOptionPane.showMessageDialog(null, "�˻����������", "��ʾ", JOptionPane.ERROR_MESSAGE);
	              }
	            }
	        });
			return button;
		}
		
		private JButton getJButtonSign(){
			JButton button = new JButton();
			button.setText("ע��");
			button.setFont(new Font("΢���ź�",0,13));
			button.setBounds(398, 260, 68, 25);
			button.setBackground(Color.white);
			button.addActionListener(new ActionListener() {
		            @Override
		            public void actionPerformed(ActionEvent e) {
		              login.setVisible(false);
		              sign.setVisible(true);
		            }
		        });
			return button;
		}
		
		/*
		private JLabel getLoginText(){
			JLabel label = new JLabel();
			label.setText("�˻�");
			label.setBounds(260, 170, 50, 30);
			label.setFont(new Font("΢���ź�",Font.BOLD,17));
			return label;
		}
		private JLabel getPassWordText(){
			JLabel label = new JLabel();
			label.setText("����");
			label.setBounds(260, 210, 50, 30);
			label.setFont(new Font("΢���ź�",Font.BOLD,17));
			return label;
		}
		*/
		
		/*ע������ʼ��
		 * 12.2
		 * �д�����
		 */
		JFrame sign = new JFrame("sign up");
		JTextField getAccount  = new JTextField();
		JTextField getPassword  = new JTextField();
		JTextField getPhone = new JTextField();
		JTextField getEmail  = new JTextField();
		
		private JLabel getUserNameText(){
			JLabel label = new JLabel();
			label.setText("�����˻�");
			label.setBounds(415, 150, 100, 30);
			label.setFont(new Font("΢���ź�",0,16));
			return label;
		}
		private JTextField getUserName(){
			getAccount.setBounds(500, 150,200,30);
			getAccount.setFont(new Font("΢���ź�",0,17));
			 return getAccount;
		}
		private JLabel getPasswordText(){
			JLabel label = new JLabel();
			label.setText("��������");
			label.setBounds(415, 210, 100, 30);
			label.setFont(new Font("΢���ź�",0,16));
			return label;
		}
		private JTextField getPassword(){
			getPassword.setBounds(500, 210,200,30);
			getPassword.setFont(new Font("΢���ź�",0,17));
			 return getPassword;
		}
		private JLabel getMailText(){
			JLabel label = new JLabel();
			label.setText("��������");
			label.setBounds(415, 270, 100, 30);
			label.setFont(new Font("΢���ź�",0,16));
			return label;
		}
		private JTextField getMail(){
			getEmail.setBounds(500, 270,200,30);
			getEmail.setFont(new Font("΢���ź�",0,17));
			 return getEmail;
		}
		private JLabel getPhoneText(){
			JLabel label = new JLabel();
			label.setText("���ĵ绰");
			label.setBounds(415, 330, 100, 30);
			label.setFont(new Font("΢���ź�",0,16));
			return label;
		}
		
		private JTextField getPhone(){
			getPhone.setBounds(500, 330,200,30);
			getPhone.setFont(new Font("΢���ź�",0,17));
			 return getPhone;
		}
		private JButton getJButtonSignNow(){
			JButton button = new JButton();
			button.setText("����ע��");
			button.setFont(new Font("΢���ź�",0,18));
			button.setBounds(502, 385, 180, 50);
			button.setBackground(Color.white);
			button.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	String account = getAccount.getText();
	            	String password = getPassword.getText();
	            	String phone = getPhone.getText();
	            	String email = getEmail.getText();
	            	Double balance = 1000.0;
	            	Customer newCus = new Customer();
	            	newCus.setAccount(account);
	            	newCus.setEmail(email);
	            	newCus.setPassword(password);
	            	newCus.setPhoneNumber(phone);
	            	newCus.setBalance(balance);
	            	Object[] obj = new Object[1];
	            	obj[0] = newCus;
	            	db.customerInsert(newCus);
	            	JOptionPane.showMessageDialog(null, "ע��ɹ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
	            	sign.setVisible(false);
	            	login.setVisible(true);
	            }
	        });
			return button;
		}
		
		/*������ʵ��
		 *
		 * 
		 */
		JFrame main = new JFrame("store");
		
		private JButton getJButtonCart(){
			JButton button = new JButton();
			button.setText("���ﳵ");
			button.setFont(new Font("΢���ź�",0,18));
			button.setBounds(20, 120, 120, 40);
			button.setBackground(Color.white);
			button.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	              main.setVisible(false);
	              cart.getContentPane().removeAll();
	              loadCart();
	              cart.setVisible(true);
	         
	            }
	        });
			return button;
		}
		private JLabel getJLabelMain(){
			JLabel l = new JLabel();
			l.setText("��Ʒ�б�");
			l.setFont(new Font("΢���ź�",0,18));
			l.setHorizontalAlignment(SwingConstants.CENTER);
			l.setBounds(20, 60, 130, 40);
			l.setBackground(Color.white);
			l.setOpaque(true);
			return l;
		}
		private JPanel getGoodsContent(Goods goods,int i){
			JPanel jp = new JPanel();
			jp.setBounds(160, 60+i*80, 500, 70);
			jp.setLayout(null);
			jp.setBackground(Color.white);
			jp.setOpaque(true);
			
			String GoodsName = "Name: "+ goods.getName();
			JLabel name = new JLabel();
			name.setBounds(3,10, 150, 40);
			name.setVerticalAlignment(SwingConstants.TOP);
			name.setText(GoodsName);
			name.setFont(new Font("΢���ź�",0,16));
			
			String GoodsPrice = "$" + goods.getPrice();
			JLabel price = new JLabel();
			price.setText(GoodsPrice);
			price.setBounds(6, 40, 150, 30);
			price.setFont(new Font("΢���ź�",0,13));
			price.setVerticalAlignment(SwingConstants.TOP);
			
			String GoodsSpecies = "Species:" + goods.getSpecies();
			JLabel species = new JLabel();
			species.setText(GoodsSpecies);
			species.setBounds(170, 7, 200, 20);
			species.setFont(new Font("΢���ź�",0,11));
			species.setVerticalAlignment(SwingConstants.TOP);
			
			String GoodsEat = "Food:" + goods.getEat();
			JLabel eat = new JLabel();
			eat.setText(GoodsEat);
			eat.setBounds(170, 30, 200, 20);
			eat.setFont(new Font("΢���ź�",0,11));
			eat.setVerticalAlignment(SwingConstants.TOP);
			
			String Goodsinventory = "Inventory:" + goods.getInventory();
			JLabel inventory = new JLabel();
			inventory.setText(Goodsinventory);
			inventory.setBounds(170, 50, 200, 20);
			inventory.setFont(new Font("΢���ź�",0,11));
			inventory.setVerticalAlignment(SwingConstants.TOP);
			
			JButton  buy = new JButton();
			buy.setText("���빺�ﳵ");
			buy.setBounds(400, 20, 90,30);
			buy.setFont(new Font("΢���ź�",0,10));
			buy.setBackground(Color.white);
			buy.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	
	            	Cart newCart = new Cart();
	            	newCart.setGoodsId(goods.getId());
	            	newCart.setCustomerId(recentAccountId);
	            	newCart.setGoodsNumber(1);
	            	
	    			ArrayList<Cart> carts = new ArrayList<Cart>();
	    			carts = db.getCartInfo();
	    			//�ж��Ƿ��Ѵ��ڸ���Ʒ
	    			int flag=0;
	    			for(Cart c: carts){
	    				if(c.getCustomerID() == recentAccountId && c.getGoodsId() ==goods.getId()){
	    					c.setGoodsNumber(c.getGoodsNumber()+1);
	    					db.cartUpdate(c);
	    					flag++;
	    				}
	    			}
	    			if(flag ==0){
	    				db.CartInsert(newCart);
	    			}
	            }
	        });
			
			
			jp.add(name);
			jp.add(buy);
			jp.add(price);
			jp.add(species);
			jp.add(eat);
			jp.add(inventory);
			return jp;
		}
		
		private void setGoodsContent(){
			ArrayList<Goods> goods = new ArrayList<Goods>();
			goods = db.getGoodsInfo();
			int i=0;
			for(Goods one:goods){
				if(i < 4)
				main.add(getGoodsContent(one,i));
				i++;
				
			}
			
		}
		
		
		/*���ﳵʵ��
		 * �д�����
		 * 
		 */
		JFrame cart = new JFrame();
		private JLabel getJLabelCart(){
			JLabel label= new JLabel();
			label.setText("���ﳵ");
			label.setFont(new Font("΢���ź�",0,18));
			label.setBounds(20, 120, 130, 40);
			label.setOpaque(true);
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setBackground(Color.white);
			return label;
		}
		private JButton getJButtonMain(){
			JButton l = new JButton();
			l.setText("��Ʒ�б�");
			l.setFont(new Font("΢���ź�",0,18));
			l.setBounds(20, 60, 120, 40);
			l.setBackground(Color.white);
			
			l.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	              cart.setVisible(false);
	             
	              main.getContentPane().removeAll();
	              loadMain();
	            
	              main.setVisible(true);
	            }
	        });
			return l;
		}
		
		private double getPriceOfCart(){
			double allPrize = 0.0;
			
			ArrayList<Cart> carts = new ArrayList<Cart>();
			carts = db.getCartInfo();
			ArrayList<Goods> goods = new ArrayList<Goods>();
			goods = db.getGoodsInfo();
			for(Cart c: carts){
				if(c.getCustomerID() == recentAccountId){
					for(Goods g:goods){
						if(c.getGoodsId() == g.getId()){
							if(c.getGoodsNumber()<=g.getInventory()){
								
								allPrize += g.getPrice() * c.getGoodsNumber();
								g.setInventory(g.getInventory()-c.getGoodsNumber());
								db.goodsUpdate(g);
							}
							else return -1;
						}
					}
					
				}
			}
			
			return allPrize;
		}
		
		private JButton getJButtonBuy(){
			JButton l = new JButton();
			l.setText("Buy Now");
			l.setFont(new Font("΢���ź�",0,18));
			l.setBounds(400, 500, 120, 40);
			l.setBackground(Color.white);
			
			l.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	
	    			double allPrice = getPriceOfCart();
	    			if(allPrice == 0){
	    				JOptionPane.showMessageDialog(null, "���ﳵΪ��", "��ʾ", JOptionPane.ERROR_MESSAGE);
	    			}
	    			else if(allPrice == -1){
	    				JOptionPane.showMessageDialog(null, "�������������", "��ʾ", JOptionPane.ERROR_MESSAGE);
	    			}
	    			else if(allPrice > recentBalance){
	    				JOptionPane.showMessageDialog(null, "����", "��ʾ", JOptionPane.ERROR_MESSAGE);
	    			}
	    			else {
	    				JOptionPane.showMessageDialog(null, "����ɹ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
	    				recentBalance = recentBalance - allPrice;
	    				Customer refresh = new Customer();
	    				refresh.setAccount(nowAccount);
	    				refresh.setId(recentAccountId);
	    				refresh.setBalance(recentBalance);
	    				db.customerUpdate(refresh);
	    				db.cartDelete(recentAccountId);
	    				
	    				  cart.setVisible(false);
	    		             
	    	              main.getContentPane().removeAll();
	    	              loadMain();
	    	         
	    	              main.setVisible(true);
	    				
	    				
	    			}
	    			
	            }
	        });
			return l;
		}
		
		private JPanel getGartContent(Goods goods,int i,int number){
			JPanel jp = new JPanel();
			jp.setBounds(160, 60+i*80, 500, 70);
			jp.setLayout(null);
			jp.setBackground(Color.white);
			jp.setOpaque(true);
			
			String GoodsName = "Name: "+ goods.getName();
			JLabel name = new JLabel();
			name.setBounds(3,10, 150, 40);
			name.setVerticalAlignment(SwingConstants.TOP);
			name.setText(GoodsName);
			name.setFont(new Font("΢���ź�",0,16));
			
			String GoodsPrice = "$" + goods.getPrice();
			JLabel price = new JLabel();
			price.setText(GoodsPrice);
			price.setBounds(6, 40, 150, 30);
			price.setFont(new Font("΢���ź�",0,13));
			price.setVerticalAlignment(SwingConstants.TOP);
			
			
			String GoodsNumber = "Number:" + number;
			JLabel gNumber = new JLabel();
			gNumber.setText(GoodsNumber);
			gNumber.setBounds(350, 15,150 , 50);
			gNumber.setFont(new Font("΢���ź�",0,13));
			jp.add(name);
			jp.add(price);
			jp.add(gNumber);
			return jp;
		}
		int CartOrder = 1;
		
		private void setCartContent(){
			ArrayList<Goods> goods = new ArrayList<Goods>();
			goods = db.getGoodsInfo();
			ArrayList<Cart> carts = new ArrayList<Cart>();
			carts = db.getCartInfo();
			int i=0;
			CartOrder++;
			for(Cart c: carts){
				if(c.getCustomerID() == recentAccountId){
					for(Goods g:goods){
						if(c.getGoodsId() == g.getId()){
							JPanel j = getGartContent(g,i,c.getGoodsNumber());
							if(i<4)
							cart.add(j);
							i++;
						}
					}
					
				}
			}
			
		}
		private void loadMain(){
			main.getContentPane().setLayout(null);
			main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			main.getContentPane().setBackground(Color.white);
			//main.add(getGoodsContent());
			main.add(getJButtonCart());
			main.add(getJLabelMain());
			setGoodsContent();
			main.add(getBackGround());
			main.setSize(800, 600);
			
		}
		private void loadCart(){
			cart.getContentPane().setLayout(null);
			cart.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			cart.getContentPane().setBackground(Color.white);
			cart.add(getJButtonMain());
			cart.add(getJLabelCart());
			setCartContent();
			cart.add(getJButtonBuy());
			cart.add(getBackGround());
			cart.setSize(800, 600);
		}
		
		public MainGUI(){
		
			try {
			     String src = "/img/logo.png";     //ͼƬ·��
			     Image image=ImageIO.read(this.getClass().getResource(src));
			     login.setIconImage(image);
			     sign.setIconImage(image);
			     main.setIconImage(image);
			     cart.setIconImage(image);
			    } catch (IOException e) {
			        e.printStackTrace();
			    }  
			//login �����ʼ��
			login.getContentPane().setLayout(null);
			login.add(getJPasswordField());
			login.add(getUsernameField());
			login.add(getJButtonLog());
			login.add(getJButtonSign());
			//login.add(getPassWordText());
			//login.add(getLoginText());
			login.add(getIcoPassword());
			login.add(getIcoUser());
			login.add(getMaintitle());
			login.add(getLogo());
			login.add(getBackGround());
			login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			login.getContentPane().setBackground(Color.white);
			login.setSize(800, 600);
			
			//sign up �����ʼ��
			sign.getContentPane().setLayout(null);
			sign.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			sign.getContentPane().setBackground(Color.white);
			sign.add(getPassword());
			sign.add(getPasswordText());
			sign.add(getUserName());
			sign.add(getUserNameText());
			sign.add(getMail());
			sign.add(getMailText());
			sign.add(getPhone());
			sign.add(getPhoneText());
			sign.add(getJButtonSignNow());
			sign.add(getBackGround());
			sign.setSize(800, 600);
			
			//main �����ʼ��
			loadMain();
			//loadCart();
			
		}
		
		
		
		
		 public static void main(String[] args){
			 MainGUI test = new MainGUI();
			 test.login.setVisible(true);
		 }

		
}


